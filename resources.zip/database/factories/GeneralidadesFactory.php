<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Generalidades;
use Faker\Generator as Faker;

$factory->define(Generalidades::class, function (Faker $faker) {
    return [
        //
    ];
});
