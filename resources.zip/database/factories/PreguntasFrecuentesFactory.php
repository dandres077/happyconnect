<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\PreguntasFrecuentes;
use Faker\Generator as Faker;

$factory->define(PreguntasFrecuentes::class, function (Faker $faker) {
    return [
        //
    ];
});
