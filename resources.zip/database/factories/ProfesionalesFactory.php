<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Profesionales;
use Faker\Generator as Faker;

$factory->define(Profesionales::class, function (Faker $faker) {
    return [
        //
    ];
});
