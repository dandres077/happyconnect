<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\MatriculasDocumentos;
use Faker\Generator as Faker;

$factory->define(MatriculasDocumentos::class, function (Faker $faker) {
    return [
        //
    ];
});
