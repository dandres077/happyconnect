<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Empresas;
use Faker\Generator as Faker;

$factory->define(Empresas::class, function (Faker $faker) {
    return [
        //
    ];
});
