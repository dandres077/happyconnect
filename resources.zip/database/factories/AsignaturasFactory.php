<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Asignaturas;
use Faker\Generator as Faker;

$factory->define(Asignaturas::class, function (Faker $faker) {
    return [
        //
    ];
});
