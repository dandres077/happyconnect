<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Periodos;
use Faker\Generator as Faker;

$factory->define(Periodos::class, function (Faker $faker) {
    return [
        //
    ];
});
