<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Niveles;
use Faker\Generator as Faker;

$factory->define(Niveles::class, function (Faker $faker) {
    return [
        //
    ];
});
