<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Cobros;
use Faker\Generator as Faker;

$factory->define(Cobros::class, function (Faker $faker) {
    return [
        //
    ];
});
