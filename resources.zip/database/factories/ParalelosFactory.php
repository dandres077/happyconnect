<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Paralelos;
use Faker\Generator as Faker;

$factory->define(Paralelos::class, function (Faker $faker) {
    return [
        //
    ];
});
