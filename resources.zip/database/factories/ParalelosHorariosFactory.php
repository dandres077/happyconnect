<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\ParalelosHorarios;
use Faker\Generator as Faker;

$factory->define(ParalelosHorarios::class, function (Faker $faker) {
    return [
        //
    ];
});
