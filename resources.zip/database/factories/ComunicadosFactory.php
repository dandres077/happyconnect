<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Comunicados;
use Faker\Generator as Faker;

$factory->define(Comunicados::class, function (Faker $faker) {
    return [
        //
    ];
});
