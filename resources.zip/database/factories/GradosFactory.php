<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Grados;
use Faker\Generator as Faker;

$factory->define(Grados::class, function (Faker $faker) {
    return [
        //
    ];
});
