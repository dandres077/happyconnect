<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Areas;
use Faker\Generator as Faker;

$factory->define(Areas::class, function (Faker $faker) {
    return [
        //
    ];
});
