<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Actividades;
use Faker\Generator as Faker;

$factory->define(Actividades::class, function (Faker $faker) {
    return [
        //
    ];
});
