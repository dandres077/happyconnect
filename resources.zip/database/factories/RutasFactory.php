<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Rutas;
use Faker\Generator as Faker;

$factory->define(Rutas::class, function (Faker $faker) {
    return [
        //
    ];
});
