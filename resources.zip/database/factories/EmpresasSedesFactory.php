<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\EmpresasSedes;
use Faker\Generator as Faker;

$factory->define(EmpresasSedes::class, function (Faker $faker) {
    return [
        //
    ];
});
