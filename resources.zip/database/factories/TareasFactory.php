<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Tareas;
use Faker\Generator as Faker;

$factory->define(Tareas::class, function (Faker $faker) {
    return [
        //
    ];
});
