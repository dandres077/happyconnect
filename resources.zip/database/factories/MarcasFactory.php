<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Marcas;
use Faker\Generator as Faker;

$factory->define(Marcas::class, function (Faker $faker) {
    return [
        //
    ];
});
