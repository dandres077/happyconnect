<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\GradosEmpresas;
use Faker\Generator as Faker;

$factory->define(GradosEmpresas::class, function (Faker $faker) {
    return [
        //
    ];
});
