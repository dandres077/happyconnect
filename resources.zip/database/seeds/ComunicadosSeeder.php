<?php

use Illuminate\Database\Seeder;
use App\Comunicados;

class ComunicadosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Vacaciones','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Cursos extra','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Horario de evaluaciones','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Graduación','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Fin de año','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Vacaciones','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Cursos extra','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Horario de evaluaciones','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Graduación','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Fin de año','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Vacaciones','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Cursos extra','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Horario de evaluaciones','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Graduación','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Fin de año','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Vacaciones','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Cursos extra','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Horario de evaluaciones','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Graduación','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Fin de año','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Vacaciones','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Cursos extra','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Horario de evaluaciones','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Graduación','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Fin de año','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Vacaciones','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Cursos extra','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Horario de evaluaciones','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Graduación','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Fin de año','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Vacaciones','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Cursos extra','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Horario de evaluaciones','descripcion'=>'Hola mundo']);
        Comunicados::create(['empresa_id' => '1', 'temporada_id' => '1', 'categoria_id'=>'1', 'nombre'=>'Graduación','descripcion'=>'Hola mundo']);

    }
}
