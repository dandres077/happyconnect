<div class="kt-footer  kt-grid__item kt-grid kt-grid--desktop kt-grid--ver-desktop" id="kt_footer">
    <div class="kt-container  kt-container--fluid ">
        <div class="kt-footer__copyright">
            <?php echo date('Y'); ?>&nbsp;&copy;&nbsp;<a href="#" target="_blank" class="kt-link">Ingeniería</a>
        </div>

        <div class="kt-footer__menu">
            <a href="#" target="_blank" class="kt-footer__menu-link kt-link">Nosotros</a>
            <a href="#" target="_blank" class="kt-footer__menu-link kt-link">Soporte</a>
            <a href="#" target="_blank" class="kt-footer__menu-link kt-link">Contáctenos</a>
        </div>
    </div>
</div>