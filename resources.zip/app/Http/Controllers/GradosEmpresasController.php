<?php

namespace App\Http\Controllers;

use App\GradosEmpresas;
use Illuminate\Http\Request;

class GradosEmpresasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\GradosEmpresas  $gradosEmpresas
     * @return \Illuminate\Http\Response
     */
    public function show(GradosEmpresas $gradosEmpresas)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\GradosEmpresas  $gradosEmpresas
     * @return \Illuminate\Http\Response
     */
    public function edit(GradosEmpresas $gradosEmpresas)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\GradosEmpresas  $gradosEmpresas
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, GradosEmpresas $gradosEmpresas)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\GradosEmpresas  $gradosEmpresas
     * @return \Illuminate\Http\Response
     */
    public function destroy(GradosEmpresas $gradosEmpresas)
    {
        //
    }
}
