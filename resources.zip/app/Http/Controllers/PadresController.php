<?php

namespace App\Http\Controllers;

use App\Padres;
use Illuminate\Http\Request;

class PadresController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Padres  $padres
     * @return \Illuminate\Http\Response
     */
    public function show(Padres $padres)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Padres  $padres
     * @return \Illuminate\Http\Response
     */
    public function edit(Padres $padres)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Padres  $padres
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Padres $padres)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Padres  $padres
     * @return \Illuminate\Http\Response
     */
    public function destroy(Padres $padres)
    {
        //
    }
}
