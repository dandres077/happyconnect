<?php

namespace App\Http\Controllers;

use App\MatriculasDocumentos;
use Illuminate\Http\Request;

class MatriculasDocumentosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\MatriculasDocumentos  $matriculasDocumentos
     * @return \Illuminate\Http\Response
     */
    public function show(MatriculasDocumentos $matriculasDocumentos)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\MatriculasDocumentos  $matriculasDocumentos
     * @return \Illuminate\Http\Response
     */
    public function edit(MatriculasDocumentos $matriculasDocumentos)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\MatriculasDocumentos  $matriculasDocumentos
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MatriculasDocumentos $matriculasDocumentos)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\MatriculasDocumentos  $matriculasDocumentos
     * @return \Illuminate\Http\Response
     */
    public function destroy(MatriculasDocumentos $matriculasDocumentos)
    {
        //
    }
}
