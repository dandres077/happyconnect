

<?php $__env->startSection('title',  $titulo  .' | '.config('app.name')); ?>

<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('assets/css/pages/tables/style.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- begin:: Subheader -->
<div class="kt-subheader   kt-grid__item" id="kt_subheader">
    <div class="kt-container  kt-container--fluid ">
        <div class="kt-subheader__main">
            <h3 class="kt-subheader__title">
                Dashboard </h3>
            <span class="kt-subheader__separator kt-hidden"></span>
            <div class="kt-subheader__breadcrumbs">
                <a href="#" class="kt-subheader__breadcrumbs-home"><i class="flaticon2-shelter"></i></a>
                <span class="kt-subheader__breadcrumbs-separator"></span>
                <a href="" class="kt-subheader__breadcrumbs-link">
                <?php echo e($titulo); ?></a>
            </div>
        </div>
    </div>
</div>
<!-- end:: Subheader -->

<!-- begin:: Content -->
<div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid">
    
<?php if(session('danger')): ?>
    <div class="alert alert-danger fade show" role="alert">
        <div class="alert-text"><?php echo e(session('danger')); ?></div>
        <div class="alert-close">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true"><i class="la la-close"></i></span>
            </button>
        </div>
    </div>
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="alert alert-success fade show" role="alert">
        <div class="alert-icon"><i class="flaticon-like"></i></div>
        <div class="alert-text"><?php echo e(session('success')); ?></div>
        <div class="alert-close">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true"><i class="la la-close"></i></span>
            </button>
        </div>
    </div>
<?php endif; ?>
    <div class="kt-portlet kt-portlet--mobile">
        <div class="kt-portlet__head kt-portlet__head--lg">
            <div class="kt-portlet__head-label">
                <span class="kt-portlet__head-icon">
                    <i class="kt-font-brand flaticon2-line-chart"></i>
                </span>
                <h3 class="kt-portlet__head-title">
                   <?php echo e($titulo); ?>

                </h3>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ciudades.create')): ?>
            <div class="kt-portlet__head-toolbar">
                <div class="kt-portlet__head-wrapper">
                    <div class="kt-portlet__head-actions">
                        <a href="<?php echo e(url ('admin/ciudades/create')); ?>" class="btn btn-brand btn-elevate btn-icon-sm">
                            <i class="la la-plus"></i>
                            Crear
                        </a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <div class="kt-portlet__body">
            <div class="table-responsive">
            <!--begin: Datatable -->
             <table class="table table-striped table-bordered table-hover dataTables-example" >
                <thead>
                <tr>
                    <th>Id</th>
                    <th>Departamento</th>
                    <th>Nombre</th>
                    <th>Estado</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciudades): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="gradeX">
                    <td><?php echo e($ciudades->id); ?></td>
                    <td><?php echo e($ciudades->nomdepartamento); ?></td>
                    <td><?php echo e($ciudades->nombre); ?></td>
                    <td>       
                        <?php if($ciudades->estado_elemento == 'Activo'): ?>
                            <span class="kt-badge  kt-badge--success kt-badge--inline kt-badge--pill">Activo</span>
                        <?php else: ?>
                            <span class="kt-badge  kt-badge--danger kt-badge--inline kt-badge--pill">Inactivo</span>
                        <?php endif; ?>
                    </td>
                    <td>   
                        <div class="dropdown dropdown-inline">
                            <button type="button" class="btn btn-brand btn-elevate-hover btn-icon btn-sm btn-icon-md btn-circle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="flaticon-more-1"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ciudades.edit')): ?> 
                                <a class="dropdown-item" href="<?php echo e(url('admin/ciudades/'.$ciudades->id.'/edit')); ?>"><i class="la la-edit"></i>Editar</a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ciudades.delete')): ?>       
                                <form method="post" action="<?php echo e(url('admin/ciudades/'.$ciudades->id)); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <button type="submit" type="button" class="dropdown-item"> <i class="la la-trash"></i>&nbsp;&nbsp;&nbsp;Eliminar</button>
                                </form>  
                                <?php endif; ?>

                                <?php if($ciudades->status == 1): ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ciudades.inactive')): ?>         
                                    <form method="post" action="<?php echo e(url('admin/ciudades/'.$ciudades->id.'/inactive')); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <button type="submit" type="button" class="dropdown-item"><i class="la la-info-circle"></i>&nbsp;&nbsp;&nbsp;Inactivar</button>
                                    </form>            
                                    <?php endif; ?>
                                <?php else: ?>    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ciudades.active')): ?>       
                                    <form method="post" action="<?php echo e(url('admin/ciudades/'.$ciudades->id.'/active')); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <button type="submit" type="button" class="dropdown-item"><i class="la la-info-circle"></i>&nbsp;&nbsp;&nbsp;Activar</button>
                                    </form>
                                    <?php endif; ?>
                                <?php endif; ?>

                            </div>
                        </div>  
                    </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </tbody>
                <tfoot>
                <tr>
                    <th>Id</th>
                    <th>Departamento</th>
                    <th>Nombre</th>
                    <th>Estado</th>

                    <th></th>

                </tr>
                </tfoot>
                </table>
            </div>
            <!--end: Datatable -->
        </div>
    </div>
</div>

<!-- end:: Content -->
                        


<?php $__env->stopSection(); ?>

   
<?php $__env->startSection('scripts'); ?>

<script src="<?php echo e(asset('plugins/dataTables/datatables.min.js')); ?>"></script>

<!-- Page-Level Scripts -->
<script>
$(document).ready(function(){
    $('.dataTables-example').DataTable({
        "order": [[ 0 ,"asc" ]], //or asc 
        pageLength: 25,
        responsive: true,
        dom: '<"html5buttons"B>lTfgitp',
        buttons: [
            //{ extend: 'copy'},
            //{extend: 'csv'},
            //{extend: 'excel', title: 'ExampleFile'},
            //{extend: 'pdf', title: 'ExampleFile'},

            /*{extend: 'print',
             customize: function (win){
                    $(win.document.body).addClass('white-bg');
                    $(win.document.body).css('font-size', '10px');

                    $(win.document.body).find('table')
                            .addClass('compact')
                            .css('font-size', 'inherit');
            }
            }*/
        ],
        "language":{
            "info": "_TOTAL_ registros",
            "search": "Buscar",
            "paginate":{
                "next": "Siguiente",
                "previous": "Anterior",
            },
            "lengthMenu": 'Ver <select>'+
                        '<option value="10">10</option>'+
                        '<option value="30">30</option>'+
                        '<option value="-1">Todo</option>'+
                        '</select> registros | ',
            "loadingRecords": "Cargando...",
            "processing": "Procesando...",
            "emptyTable": "No hay datos",
            "infoEmpty": "",
            "infoFiltered": ""
        }

    });

});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\happyconnect\resources\views/ciudades/index.blade.php ENDPATH**/ ?>