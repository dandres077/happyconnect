

<?php $__env->startSection('title',  $titulo  .' | '.config('app.name')); ?>

<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('assets/css/pages/tables/style.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- begin:: Subheader -->
<div class="kt-subheader   kt-grid__item" id="kt_subheader">
    <div class="kt-container  kt-container--fluid ">
        <div class="kt-subheader__main">
            <h3 class="kt-subheader__title">
                Dashboard </h3>
            <span class="kt-subheader__separator kt-hidden"></span>
            <div class="kt-subheader__breadcrumbs">
                <a href="#" class="kt-subheader__breadcrumbs-home"><i class="flaticon2-shelter"></i></a>
                <span class="kt-subheader__breadcrumbs-separator"></span>
                <a href="" class="kt-subheader__breadcrumbs-link">
                <?php echo e($titulo); ?></a>
            </div>
        </div>
    </div>
</div>
<!-- end:: Subheader -->

<!-- begin:: Content -->
<div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid">
<?php if(session('danger')): ?>
    <div class="alert alert-danger fade show" role="alert">
        <div class="alert-text"><?php echo e(session('danger')); ?></div>
        <div class="alert-close">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true"><i class="la la-close"></i></span>
            </button>
        </div>
    </div>
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="alert alert-success fade show" role="alert">
        <div class="alert-icon"><i class="flaticon-like"></i></div>
        <div class="alert-text"><?php echo e(session('success')); ?></div>
        <div class="alert-close">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true"><i class="la la-close"></i></span>
            </button>
        </div>
    </div>
<?php endif; ?>
    <div class="kt-portlet kt-portlet--mobile">
        <div class="kt-portlet__head kt-portlet__head--lg">
            <div class="kt-portlet__head-label">
                <span class="kt-portlet__head-icon">
                    <i class="kt-font-brand flaticon2-line-chart"></i>
                </span>
                <h3 class="kt-portlet__head-title">
                   <?php echo e($titulo); ?>

                </h3>
            </div>

            <div class="btn-group">
                <button type="button" class="btn btn-brand btn-elevate btn-icon-sm">
                    Matricular </button>
                <button type="button" class="btn btn-brand btn-bold dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                </button>
                <div class="dropdown-menu dropdown-menu-right">
                    <ul class="kt-nav">
                        <li class="kt-nav__item">
                            <a href="#" class="kt-nav__link" data-toggle="modal" data-target="#kt_modal_1">
                                <i class="kt-nav__link-icon flaticon2-writing"></i>
                                <span class="kt-nav__link-text">Institución</span>
                            </a>
                        </li>
                        <li class="kt-nav__item">
                            <a href="#" class="kt-nav__link" data-toggle="modal" data-target="#kt_modal_5">
                                <i class="kt-nav__link-icon flaticon2-medical-records"></i>
                                <span class="kt-nav__link-text">Padre</span>
                            </a>
                        </li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('matriculas.reporte')): ?>
                        <li class="kt-nav__item">
                            <a href="<?php echo e(url ('admin/matriculas/reporte')); ?>" class="kt-nav__link">
                                <i class="kt-nav__link-icon flaticon2-medical-records"></i>
                                <span class="kt-nav__link-text">Reporte</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('matriculas.importar')): ?>
                        <li class="kt-nav__item">
                            <a href="" class="kt-nav__link" data-toggle="modal" data-target="#kt_modal_6">
                                <i class="kt-nav__link-icon flaticon2-medical-records"></i>
                                <span class="kt-nav__link-text">Importar</span>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>

        </div>
        <div class="kt-portlet__body">
            <div class="table-responsive">
            <!--begin: Datatable -->
             <table class="table table-striped table-bordered table-hover dataTables-example" >
                <thead>
                <tr>
                    <th>Id</th>
                    <th>Temporada</th>
                    <th>Jornada</th>
                    <th>Grado</th>
                    <th>Paralelo</th>
                    <th>Estudiante</th>
                    <th>TipoDocumento</th>
                    <th>N° Documento</th>
                    <th>Estado</th>
                    <th>Opciones</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matriculas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="gradeX">
                    <td><?php echo e($matriculas->id); ?></td>
                    <td><?php echo e($matriculas->nom_temporada); ?></td>
                    <td><?php echo e($matriculas->nom_jornada); ?></td>
                    <td><?php echo e($matriculas->nom_grado); ?></td>
                    <td><?php echo e($matriculas->nom_paralelo); ?></td>
                    <td><?php echo e(strtoupper($matriculas->nom_alumno)); ?></td>
                    <td><?php echo e($matriculas->tipodoc); ?></td>
                    <td><?php echo e($matriculas->n_documento); ?></td>
                    <td>
                        <?php if($matriculas->estado_elemento == 'Activo'): ?>
                            <span class="kt-badge  kt-badge--success kt-badge--inline kt-badge--pill">Activo</span>
                        <?php else: ?>
                            <span class="kt-badge  kt-badge--danger kt-badge--inline kt-badge--pill">Inactivo</span>
                        <?php endif; ?>
                    </td>
                    <td>  
                        <div class="dropdown dropdown-inline">
                            <button type="button" class="btn btn-brand btn-elevate-hover btn-icon btn-sm btn-icon-md btn-circle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="flaticon-more-1"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('matriculas.edit')): ?> 
                                <a class="dropdown-item" href="<?php echo e(url('admin/matriculas/'.$matriculas->id.'/edit')); ?>"><i class="la la-edit"></i>Editar</a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('matriculas.delete')): ?>       
                                <form method="post" action="<?php echo e(url('admin/matriculas/'.$matriculas->id.'/delete')); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <button type="submit" type="button" class="dropdown-item"> <i class="la la-trash"></i>&nbsp;&nbsp;&nbsp;Eliminar</button>
                                </form>  
                                <?php endif; ?>

                                <?php if($matriculas->status == 5): ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('matriculas.inactive')): ?>         
                                    <form method="post" action="<?php echo e(url('admin/matriculas/'.$matriculas->id.'/inactive')); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <button type="submit" type="button" class="dropdown-item"><i class="la la-info-circle"></i>&nbsp;&nbsp;&nbsp;Inactivar</button>
                                    </form>            
                                    <?php endif; ?>
                                <?php else: ?>    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('matriculas.active')): ?>       
                                    <form method="post" action="<?php echo e(url('admin/matriculas/'.$matriculas->id.'/active')); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <button type="submit" type="button" class="dropdown-item"><i class="la la-info-circle"></i>&nbsp;&nbsp;&nbsp;Activar</button>
                                    </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>                       
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </tbody>
                <tfoot>
                <tr>
                    <th>Id</th>
                    <th>Temporada</th>
                    <th>Jornada</th>
                    <th>Grado</th>
                    <th>Paralelo</th>
                    <th>Estudiante</th>
                    <th>TipoDocumento</th>
                    <th>N° Documento</th>
                    <th>Estado</th>
                    <th>Opciones</th>
                </tr>
                </tfoot>
                </table>
            </div>
            <!--end: Datatable -->
        </div>
    </div>
</div>

<!--begin::Modal-->
<div class="modal fade" id="kt_modal_5" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Matricula - Padre</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">
                <form method="post" action="<?php echo e(url('admin/matriculas/store3')); ?>"  autocomplete="off">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="recipient-name" class="form-control-label">N° Documento alumno:</label>
                        <input type="number" class="form-control" name="n_documento" min="1" max="9999999999" required="">
                    </div>
                    <div class="form-group">
                        <label for="recipient-name" class="form-control-label">Temporada:</label>
                        <select class="form-control" name="temporada_id" id="temporada_id" required="">
                        <?php $__currentLoopData = $temporadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temporada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($temporada->id); ?>"> <?php echo e($temporada->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                         
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="recipient-name" class="form-control-label">Grado:</label>
                        <select class="form-control" name="grado_id" id="grado_id" required="">
                        <?php $__currentLoopData = $grados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($grado->id); ?>"> <?php echo e($grado->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                         
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="recipient-name" class="form-control-label">Email Padre:</label>
                        <input type="email" class="form-control" name="email" required="">
                    </div>                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('matriculas.store3')): ?>
                <button type="submit" class="btn btn-primary">Matricular y notificar</button>
                <?php endif; ?>
            </div>
            </form>
        </div>
    </div>
</div>

<!--end::Modal-->

<!--begin::Modal-->
<div class="modal fade" id="kt_modal_6" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Seleccione <a href="https://www.central.gidesco.com/img/CargueExcel_Plantilla.xlsx" target="_blank">(Plantilla)</a></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">
                <form method="post" class="form-horizontal" action="<?php echo e(url('admin/matriculas/masivo')); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="recipient-name" class="form-control-label">Importar:</label>
                        <input type="file" name="archivo_excel">
                    </div>                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Importar</button>
            </div>
            </form>
        </div>
    </div>
</div>

<!--end::Modal--> 


<!--begin::Modal-->
<div class="modal fade" id="kt_modal_1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Matricula Institucional</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">
                <form method="post" action="<?php echo e(url('admin/matriculas/validar')); ?>"  autocomplete="off">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="recipient-name" class="form-control-label">N° Documento alumno:</label>
                        <input type="number" class="form-control" name="n_documento" min="1" max="9999999999" required="">
                    </div>
                    <div class="form-group">
                        <label for="recipient-name" class="form-control-label">Periodo:</label>
                        <select class="form-control" name="temporada_id" id="temporada_id" required="">
                        <?php $__currentLoopData = $temporadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temporada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($temporada->id); ?>"> <?php echo e($temporada->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                         
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="recipient-name" class="form-control-label">Grado:</label>
                        <select class="form-control" name="grado_id" id="grado_id" required="">
                        <?php $__currentLoopData = $grados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($grado->id); ?>"> <?php echo e($grado->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                         
                        </select>
                    </div>            
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('matriculas.validar')): ?>
                <button type="submit" class="btn btn-primary">Validar</button>
                <?php endif; ?>
            </div>
            </form>
        </div>
    </div>
</div>

<!--end::Modal-->

<!-- end:: Content -->
                        


<?php $__env->stopSection(); ?>

   
<?php $__env->startSection('scripts'); ?>

<script src="<?php echo e(asset('plugins/dataTables/datatables.min.js')); ?>"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

<?php if(session('eliminar')=='ok'): ?>
<script>
    Swal.fire(
      '¡Eliminado!',
      'Registro eliminado exitosamente.',
      'success'
    )
</script>

<?php endif; ?>

<script>

    $('.formulario-eliminar').submit(function(e){
        e.preventDefault();
        Swal.fire({
          title: '¿Esta seguro?',
          text: "¡No podra revertir esta acción!",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Si, estoy seguro',
          cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.value) {
              this.submit();
            }          
        })
    });
    
</script>


<!-- Page-Level Scripts -->
<script>
$(document).ready(function(){
    $('.dataTables-example').DataTable({
        "order": [[ 0 ,"asc" ]], //or asc 
        pageLength: 25,
        responsive: true,
        dom: '<"html5buttons"B>lTfgitp',
        buttons: [
            //{ extend: 'copy'},
            //{extend: 'csv'},
            {extend: 'excel', title: 'AlumnosMatriculados'},
            //{extend: 'pdf', title: 'ExampleFile'},

            /*{extend: 'print',
             customize: function (win){
                    $(win.document.body).addClass('white-bg');
                    $(win.document.body).css('font-size', '10px');

                    $(win.document.body).find('table')
                            .addClass('compact')
                            .css('font-size', 'inherit');
            }
            }*/
        ],
        "language":{
            "info": "_TOTAL_ registros",
            "search": "Buscar",
            "paginate":{
                "next": "Siguiente",
                "previous": "Anterior",
            },
            "lengthMenu": 'Ver <select>'+
                        '<option value="10">10</option>'+
                        '<option value="30">30</option>'+
                        '<option value="-1">Todo</option>'+
                        '</select> registros | ',
            "loadingRecords": "Cargando...",
            "processing": "Procesando...",
            "emptyTable": "No hay datos",
            "infoEmpty": "",
            "infoFiltered": ""
        }

    });

});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\happyconnect\resources\views/matriculas/index.blade.php ENDPATH**/ ?>