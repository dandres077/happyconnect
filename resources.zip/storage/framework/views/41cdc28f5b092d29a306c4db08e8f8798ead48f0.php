

<?php $__env->startSection('title',  $titulo  .' | '.config('app.name')); ?>

<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('assets/css/pages/tables/style.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- begin:: Subheader -->
<div class="kt-subheader   kt-grid__item" id="kt_subheader">
    <div class="kt-container  kt-container--fluid ">
        <div class="kt-subheader__main">
            <h3 class="kt-subheader__title">
                Dashboard </h3>
            <span class="kt-subheader__separator kt-hidden"></span>
            <div class="kt-subheader__breadcrumbs">
                <a href="#" class="kt-subheader__breadcrumbs-home"><i class="flaticon2-shelter"></i></a>
                <span class="kt-subheader__breadcrumbs-separator"></span>
                <a href="" class="kt-subheader__breadcrumbs-link">
                <?php echo e($titulo); ?></a>
            </div>
        </div>
    </div>
</div>
<!-- end:: Subheader -->

<!-- begin:: Content -->
<div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid">
	<div class="row">
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entradas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col-xl-4">

			<!--begin:: Widgets/Blog-->
			<div class="kt-portlet kt-portlet--height-fluid kt-widget19">
				<div class="kt-portlet__body kt-portlet__body--fit kt-portlet__body--unfill">
					<div class="kt-widget19__pic kt-portlet-fit--top kt-portlet-fit--sides" style="min-height: 300px; background-image: url(<?php echo e($entradas->imagen); ?>)">
						<h3 class="kt-widget19__title kt-font-light">
							<?php echo e($entradas->titulo); ?>

						</h3>
						<div class="kt-widget19__shadow"></div>
						<div class="kt-widget19__labels">
							<a href="#" class="btn btn-label-light-o2 btn-bold "><?php echo e($entradas->nom_categoria); ?></a>
						</div>
					</div>
				</div>
				<div class="kt-portlet__body">
					<div class="kt-widget19__wrapper">
						<div class="kt-widget19__content">
							<div class="kt-widget19__userpic">
								<img src="<?php echo e($entradas->img_usuario); ?>" alt="">
							</div>
							<div class="kt-widget19__info">
								<a href="#" class="kt-widget19__username">
									<?php echo e($entradas->nom_usuario); ?>

								</a>
							</div>
							<span class="kt-widget19__time"><?php echo e($entradas->created_at); ?></span>
						</div>
						<div class="kt-widget19__text">
							<?php echo e(Str::limit($entradas->texto, 150)); ?>

						</div>
					</div>
					<div class="kt-widget19__action">
						<a href="<?php echo e(url('admin/blog/'.$entradas->id.'/show')); ?>" class="btn btn-sm btn-label-brand btn-bold">Leer más</a>
					</div>
				</div>
			</div>

			<!--end:: Widgets/Blog-->
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<!-- end:: Content -->
<?php $__env->stopSection(); ?>

   
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\happyconnect\resources\views/blogs/show.blade.php ENDPATH**/ ?>