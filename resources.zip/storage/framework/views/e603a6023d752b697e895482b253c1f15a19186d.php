

<?php $__env->startSection('title',  $titulo  .' | '.config('app.name')); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- begin:: Subheader -->
<div class="kt-subheader   kt-grid__item" id="kt_subheader">
    <div class="kt-container  kt-container--fluid ">
        <div class="kt-subheader__main">
            <h3 class="kt-subheader__title">
                Dashboard </h3>
            <span class="kt-subheader__separator kt-hidden"></span>
            <div class="kt-subheader__breadcrumbs">
                <a href="#" class="kt-subheader__breadcrumbs-home"><i class="flaticon2-shelter"></i></a>
                <span class="kt-subheader__breadcrumbs-separator"></span>
                <a href="" class="kt-subheader__breadcrumbs-link">
                <?php echo e($titulo); ?></a>
            </div>
        </div>
    </div>
</div>
<!-- end:: Subheader -->

<!-- begin:: Content -->
<div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid">
	<div class="row">
		<div class="col-xl-12 col-lg-12">
			<!--begin:: Widgets/Sale Reports-->
			<div class="kt-portlet kt-portlet--tabs kt-portlet--height-fluid">
				<div class="kt-portlet__head">
					<div class="kt-portlet__head-label">
						<h3 class="kt-portlet__head-title">
							Actividades
						</h3>
					</div>
					<div class="kt-portlet__head-toolbar">
						<ul class="nav nav-tabs nav-tabs-line nav-tabs-bold nav-tabs-line-brand" role="tablist">
							<li class="nav-item">
								<a class="nav-link active" data-toggle="tab" href="#kt_widget11_tab1_content" role="tab">
									Recientes
								</a>
							</li>
						</ul>
					</div>
				</div>
				<div class="kt-portlet__body">

					<!--Begin::Tab Content-->
					<div class="tab-content">

						<!--begin::tab 1 content-->
						<div class="tab-pane active" id="kt_widget11_tab1_content">

							<!--begin::Widget 11-->
							<div class="kt-widget11">
								<div class="table-responsive">
									<table class="table">
										<thead>
											<tr>
												<td style="width:60%">Tarea</td>
												<td style="width:15%">Asignatura</td>
												<td style="width:10%">Status</td>
												<td style="width:15%" class="kt-align-right">Fecha de entrega</td>
											</tr>
										</thead>
										<tbody>
											<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tareas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td>
													<span class="kt-widget11__sub"><?php echo e($tareas->tarea); ?></span>
													<a href="#" class="kt-widget11__title">Prof. <?php echo e($tareas->nom_docente); ?></a>	
												</td>
												<td><span class="kt-badge kt-badge--inline kt-badge--success"><?php echo e($tareas->nom_asignatura); ?></span></td>
												<td>
												<?php if(strtotime($tareas->fecha_entrega) < strtotime('today')): ?>
													<span class="kt-badge kt-badge--inline kt-badge--danger">Vencido</span>
												<?php else: ?>
													<span class="kt-badge kt-badge--inline kt-badge--info">Activo</span>
												<?php endif; ?>
												</td>
												<td class="kt-align-right kt-font-brand kt-font-bold<?php echo e((strtotime($tareas->fecha_entrega) < strtotime('today')) ? ' kt-font-danger' : ''); ?>"><?php echo e($tareas->fecha_entrega); ?></td>
											</tr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</tbody>
									</table>
								</div>
							</div>

							<!--end::Widget 11-->
						</div>

						<!--end::tab 1 content-->

					</div>

					<!--End::Tab Content-->
				</div>
			</div>
			<!--end:: Widgets/Sale Reports-->
		</div>
	</div>
</div>

<!-- end:: Content -->
                        


<?php $__env->stopSection(); ?>

   
<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\happyconnect\resources\views/tareas/show.blade.php ENDPATH**/ ?>