

<?php $__env->startSection('title',  $titulo  .' | '.config('app.name')); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- begin:: Subheader -->
<div class="kt-subheader   kt-grid__item" id="kt_subheader">
    <div class="kt-container  kt-container--fluid ">
        <div class="kt-subheader__main">
            <h3 class="kt-subheader__title">
                Dashboard </h3>
            <span class="kt-subheader__separator kt-hidden"></span>
            <div class="kt-subheader__breadcrumbs">
                <a href="#" class="kt-subheader__breadcrumbs-home"><i class="flaticon2-shelter"></i></a>
                <span class="kt-subheader__breadcrumbs-separator"></span>
                <a href="" class="kt-subheader__breadcrumbs-link">
                <?php echo e($titulo); ?></a>
            </div>
        </div>
    </div>
</div>
<!-- end:: Subheader -->

<!-- begin:: Content -->
<div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid">

	<!--Begin::App-->
	<div class="kt-grid kt-grid--desktop kt-grid--ver kt-grid--ver-desktop kt-app">

		<!--Begin:: App Aside Mobile Toggle-->
		<button class="kt-app__aside-close" id="kt_user_profile_aside_close">
			<i class="la la-close"></i>
		</button>

		<!--End:: App Aside Mobile Toggle-->

		<!--Begin:: App Content-->
		<div class="kt-grid__item kt-grid__item--fluid kt-app__content">
			<div class="row">
				<div class="col-xl-12">

					<!--begin:: Widgets/Tasks -->
					<div class="kt-portlet kt-portlet--tabs kt-portlet--height-fluid">
						<div class="kt-portlet__head">
							<div class="kt-portlet__head-label">
								<h3 class="kt-portlet__head-title">
									<?php echo e($titulo); ?>

								</h3>
							</div>
							<div class="kt-portlet__head-toolbar">
								<ul class="nav nav-tabs nav-tabs-line nav-tabs-bold nav-tabs-line-brand" role="tablist">
									<li class="nav-item">
										<a class="nav-link active" data-toggle="tab" href="#kt_widget2_tab1_content" role="tab" aria-selected="true">
											Información general
										</a>
									</li>
								</ul>
							</div>
						</div>
						<div class="kt-portlet__body">
							<div class="tab-content">
								<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="tab-pane active" id="kt_widget2_tab1_content">
									<div class="kt-widget2">
										<div class="kt-widget2__item kt-widget2__item--primary">
											<div class="kt-widget2__checkbox">

											</div>
											<div class="kt-widget2__info">
												<a href="#" class="kt-widget2__title">
													<?php echo e($info->nombre); ?>

												</a>
												<a href="#" class="kt-widget2__username">
													<?php echo e($info->descripcion); ?>

												</a>
												<a href="#" class="kt-widget2__username">
													<?php echo e($info->created_at); ?>

												</a>
											</div>
											<div class="kt-widget2__actions">
												<a href="#" class="btn btn-clean btn-sm btn-icon btn-icon-md" data-toggle="dropdown" aria-expanded="false">
													<i class="flaticon-more-1"></i>
												</a>
												<div class="dropdown-menu dropdown-menu-fit dropdown-menu-right" style="">
													<ul class="kt-nav">
														<?php if($info->imagen): ?>
														<li class="kt-nav__item">
															<a href="<?php echo e($info->imagen); ?>" target="_blank" class="kt-nav__link">
																<i class="kt-nav__link-icon flaticon-eye"></i>
																<span class="kt-nav__link-text">Ver <?php echo e(\App\Http\Controllers\ComunicadosController::obtenerTipoArchivo($info->imagen)); ?> </span>
															</a>
														</li>
														<?php endif; ?>
														<?php if($info->archivo1): ?>
														<li class="kt-nav__item">
														    <a href="<?php echo e($info->archivo1); ?>" target="_blank" class="kt-nav__link">
														        <i class="kt-nav__link-icon flaticon-eye"></i>
														        <span class="kt-nav__link-text">Ver <?php echo e(\App\Http\Controllers\ComunicadosController::obtenerTipoArchivo($info->archivo1)); ?></span>
														    </a>  
														</li>

														<?php endif; ?>
														<?php if($info->archivo2): ?>
														<li class="kt-nav__item">
															<a href="<?php echo e($info->archivo2); ?>" target="_blank" class="kt-nav__link">
																<i class="kt-nav__link-icon flaticon-eye"></i>
																<span class="kt-nav__link-text">Ver <?php echo e(\App\Http\Controllers\ComunicadosController::obtenerTipoArchivo($info->archivo2)); ?></span>
															</a>
														</li>
														<?php endif; ?>
														<?php if($info->archivo3): ?>
														<li class="kt-nav__item">
															<a href="<?php echo e($info->archivo3); ?>" target="_blank" class="kt-nav__link">
																<i class="kt-nav__link-icon flaticon-eye"></i>
																<span class="kt-nav__link-text">Ver <?php echo e(\App\Http\Controllers\ComunicadosController::obtenerTipoArchivo($info->archivo3)); ?></span>
															</a>
														</li>
														<?php endif; ?>
													</ul>
												</div>
											</div>
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
					</div>

					<!--end:: Widgets/Tasks -->
				</div>
			</div>
		</div>

		<!--End:: App Content-->
	</div>

	<!--End::App-->
</div>

<!-- end:: Content -->
                        


<?php $__env->stopSection(); ?>

   
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\happyconnect\resources\views/comunicados/show.blade.php ENDPATH**/ ?>