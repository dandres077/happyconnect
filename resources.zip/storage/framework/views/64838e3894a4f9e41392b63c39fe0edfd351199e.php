

<?php $__env->startSection('title', $titulo .' | '.config('app.name')); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- begin:: Subheader -->
<div class="kt-subheader   kt-grid__item" id="kt_subheader">
    <div class="kt-container  kt-container--fluid ">
        <div class="kt-subheader__main">
            <h3 class="kt-subheader__title">
                Dashboard </h3>
            <span class="kt-subheader__separator kt-hidden"></span>
            <div class="kt-subheader__breadcrumbs">
                <a href="<?php echo e(url ('admin/comunicados')); ?>" class="kt-subheader__breadcrumbs-home"><i class="flaticon2-shelter"></i></a>
                <span class="kt-subheader__breadcrumbs-separator"></span>
                <a href="<?php echo e(url ('admin/comunicados')); ?>" class="kt-subheader__breadcrumbs-link">
                <?php echo e($titulo); ?></a>
                <span class="kt-subheader__breadcrumbs-separator"></span>
                <a href="" class="kt-subheader__breadcrumbs-link">
                Crear </a>
            </div>
        </div>
    </div>
</div>

<!-- end:: Subheader -->

<!-- begin:: Content -->
<div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid">
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
    <div class="row">
        <div class="col-lg-12">
            <!--begin::Portlet-->
            <div class="kt-portlet kt-portlet--last kt-portlet--head-lg kt-portlet--responsive-mobile" id="kt_page_portlet">
                <div class="kt-portlet__head kt-portlet__head--lg">
                    <div class="kt-portlet__head-label">
                        <h3 class="kt-portlet__head-title"><?php echo e($titulo); ?></h3>
                    </div>
                </div>
                <div class="kt-portlet__body">
                    <form method="post" class="form-horizontal" action="<?php echo e(url('admin/comunicados/store')); ?>" autocomplete="off" enctype="multipart/form-data" onsubmit="return validar(this)">
                    <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-6">
                                <div class="kt-section kt-section--first">
                                    <div class="kt-section__body">  

                                        <div class="form-group row">
                                            <label class="col-3 col-form-label">Temporada </label>
                                            <div class="col-9">
                                                <select class="form-control" name="temporada_id" id="temporada_id">
                                                <?php $__currentLoopData = $temporadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temporada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($temporada->id); ?>"> <?php echo e($temporada->nombre); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                         
                                                </select>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-3 col-form-label">Nombre </label>
                                            <div class="col-9">
                                            <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo e(old('nombre')); ?>" required="">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-3 col-form-label">Archivo 1</label>
                                            <div class="col-9">
                                            <input type="file" class="form-control-file" name="archivo1" id="archivo1">
                                            </div>
                                        </div> 

                                        <div class="form-group row">
                                            <label class="col-3 col-form-label">Archivo 3</label>
                                            <div class="col-9">
                                            <input type="file" class="form-control-file" name="archivo3" id="archivo3">
                                            </div>
                                        </div>                                          

                                    </div>
                                </div>    
                            </div>
                            <div class="col-6">
                                <div class="kt-section kt-section--first">
                                    <div class="kt-section__body">   

                                        <div class="form-group row">
                                            <label class="col-3 col-form-label">Categoría </label>
                                            <div class="col-9">
                                                <select class="form-control" name="categoria_id" id="categoria_id">
                                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($categoria->id); ?>"> <?php echo e($categoria->nombre); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                         
                                                </select>
                                            </div>
                                        </div>  

                                        <div class="form-group row">
                                            <label class="col-3 col-form-label">Descripción </label>
                                            <div class="col-9">
                                            <input type="text" class="form-control" id="descripcion" name="descripcion" value="<?php echo e(old('descripcion')); ?>" required="">
                                            </div>
                                        </div>       

                                        <div class="form-group row">
                                            <label class="col-3 col-form-label">Archivo 2</label>
                                            <div class="col-9">
                                            <input type="file" class="form-control-file" name="archivo2" id="archivo2">
                                            </div>
                                        </div>                                                                    
                                    </div>
                                </div>                                
                            </div>                            
                        </div>

                        <h2 class="kt-font-success">Seleccione los grados</h2> <br>

                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group row">
                                    <div class="col-12">
                                        <div class="kt-checkbox-list">
                                            <div class="row">
                                                <?php $count = 0; ?>
                                                <?php $__currentLoopData = $paralelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paralelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($count % 3 === 0 && $count > 0): ?>
                                                        </div>
                                                        <div class="row">
                                                    <?php endif; ?>
                                                    <div class="col-md-4">
                                                        <label class="kt-checkbox">
                                                            <input type="checkbox" name="paralelos[]" value="<?php echo e($paralelo->id); ?>"> <?php echo e($paralelo->nom_paralelo); ?>

                                                            <span></span>
                                                        </label>
                                                    </div>
                                                    <?php $count++; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <label class="kt-checkbox">
                                                <input type="checkbox" id="check-all"> Marcar todos
                                                <span></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="kt-separator kt-separator--border-dashed kt-separator--space-lg"></div>

                        <div class="hr-line-dashed"></div>

                        <div class="kt-form__actions">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('comunicados.store')): ?> 
                            <button type="submit" class="btn btn-primary" name="enviar">Crear</button>
                            <?php endif; ?>
                            <a href="<?php echo e(url ('admin/comunicados')); ?>" class="btn btn-secondary">Cancelar</a>
                        </div>
                    </form>
                </div>
            </div>

            <!--end::Portlet-->
        </div>
    </div>
</div>

<!-- end:: Content -->

<?php $__env->stopSection(); ?>
    
<?php $__env->startSection('scripts'); ?>

<script>
    $(document).ready(function() {
        $('#check-all').click(function() {
            $('.kt-checkbox-list input[type="checkbox"]').prop('checked', this.checked);
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\happyconnect\resources\views/comunicados/create.blade.php ENDPATH**/ ?>