

<?php $__env->startSection('title',  $titulo  .' | '.config('app.name')); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- begin:: Subheader -->
<div class="kt-subheader   kt-grid__item" id="kt_subheader">
    <div class="kt-container  kt-container--fluid ">
        <div class="kt-subheader__main">
            <h3 class="kt-subheader__title">
                Dashboard </h3>
            <span class="kt-subheader__separator kt-hidden"></span>
            <div class="kt-subheader__breadcrumbs">
                <a href="#" class="kt-subheader__breadcrumbs-home"><i class="flaticon2-shelter"></i></a>
                <span class="kt-subheader__breadcrumbs-separator"></span>
                <a href="" class="kt-subheader__breadcrumbs-link">
                <?php echo e($titulo); ?></a>
            </div>
        </div>
    </div>
</div>
<!-- end:: Subheader -->

<!-- begin:: Content -->
<div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid">
	<div class="row">
		<div class="col-xl-12">

			<!--begin:: Widgets/Personal Income-->
			<div class="kt-portlet kt-portlet--fit kt-portlet--head-lg kt-portlet--head-overlay kt-portlet--height-fluid">
				<div class="kt-portlet__head kt-portlet__space-x">
					<div class="kt-portlet__head-label">
						<h3 class="kt-portlet__head-title kt-font-light">
							<?php echo e($data[0]->nom_alumno); ?>

						</h3>
					</div>
				</div>
				<div class="kt-portlet__body">
					<div class="kt-widget27">
						<div class="kt-widget27__visual">
							<img src="<?php echo e(asset('assets/media/bg/bg-4.jpg')); ?>" alt="">
							<h3 class="kt-widget27__title">
								<?php
									$realizado = 0;
									$pendiente = 0;
								?>

								<?php $__currentLoopData = $cobros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cobro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

								<?php if($cobro->status == 1): ?>

								<?php
									$realizado = $realizado + $cobro->valor;

								?>

								<?php endif; ?>

								<?php if($cobro->status == 2): ?>

								<?php
									$pendiente = $pendiente + $cobro->valor;

								?>
								
								<?php endif; ?>								

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<span class="kt-font-success kt-font-bold"><?php echo e(number_format($realizado,'0', ',','.')); ?></span><br>
								<span class="kt-font-danger kt-font-bold"><?php echo e(number_format($pendiente,'0', ',','.')); ?></span>
							</h3>
							<div class="kt-widget27__btn">
								<a href="#" class="btn btn-pill btn-light btn-elevate btn-bold">Pagos</a>
							</div>
						</div>
						<div class="kt-widget27__container kt-portlet__space-x">
							<ul class="nav nav-pills nav-fill" role="tablist">
							<?php $__currentLoopData = $meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							    <li class="nav-item">
							        <a class="nav-link<?php echo e(($index === 0) ? ' active' : ''); ?>" data-toggle="pill" href="#kt_personal_income_quater_<?php echo e($mes->id); ?>"><?php echo e($mes->nombre); ?></a>
							    </li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</ul>
							<div class="tab-content">
								<?php $__currentLoopData = $meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    							<div id="kt_personal_income_quater_<?php echo e($mes->id); ?>" class="tab-pane<?php echo e(($index === 0) ? ' active' : ''); ?>">
									<div class="kt-widget11">
										<div class="table-responsive">
											<!--begin::Table-->
											<table class="table">
												<!--begin::Thead-->
												<thead>
													<tr>
														<td>Concepto</td>
														<td>Fecha</td>
														<td>Estado</td>
														<td class="kt-align-right">Valor</td>
													</tr>
												</thead>

												<!--end::Thead-->

												<!--begin::Tbody-->
												<tbody>
													<?php $__currentLoopData = $cobros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cobro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<?php if($mes->id == $cobro->mes_id): ?>
													<tr>
														<td>
															<a href="#" class="kt-widget11__title"><?php echo e($cobro->nombre); ?></a>
															<span class="kt-widget11__sub"><?php echo e($cobro->observacion); ?></span>
														</td>
														
														<?php if($cobro->status == 1): ?>
														<td><span class="kt-badge kt-badge--success kt-badge--inline"><?php echo e($cobro->fecha); ?></span></td>
														<td><span class="kt-badge kt-badge--success kt-badge--inline">Realizado</span></td>
														<?php endif; ?>
														<?php if($cobro->status == 2): ?>
														<td><span class="kt-badge kt-badge--danger kt-badge--inline">Pendiente</span></td>
														<td><span class="kt-badge kt-badge--danger kt-badge--inline">Pendiente</span></td>
														<?php endif; ?>

														<td class="kt-align-right kt-font-brand kt-font-bold">$ <?php echo e(number_format($cobro->valor,'0', ',','.')); ?></td>
													</tr>
													<?php endif; ?>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</tbody>
												<!--end::Tbody-->
											</table>
											<!--end::Table-->
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
					</div>
				</div>
			</div>

			<!--end:: Widgets/Personal Income-->
		</div>
	</div>
</div>

<!-- end:: Content -->



<?php $__env->stopSection(); ?>

   
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\happyconnect\resources\views/cobros/show.blade.php ENDPATH**/ ?>